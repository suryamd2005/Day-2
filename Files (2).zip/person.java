package day3;

abstract class Person {

    // Abstract Method
    abstract void displayDetails();
}

interface SalaryCalculation {

    // Interface Method
    void calculateSalary();
}

class Employee extends Person implements SalaryCalculation {

    int empId;
    String empName;
    double salary;

    Employee(int empId, String empName, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.salary = salary;
    }

    @Override
    void displayDetails() {
        System.out.println("Employee ID: " + empId);
        System.out.println("Employee Name: " + empName);
    }

    @Override
    public void calculateSalary() {
        System.out.println("Employee Salary: Rs." + salary);
    }
}

public class Main {
    public static void main(String[] args) {

        Employee emp = new Employee(101, "Shrutin", 50000);

        emp.displayDetails();
        emp.calculateSalary();
    }
}