package day3;

class Calculator {

    // Method 1
    int add(int a, int b) {
        return a + b;
    }

    // Method 2
    int add(int a, int b, int c) {
        return a + b + c;
    }

    // Method 3
    double add(double a, double b) {
        return a + b;
    }

    public static void main(String[] args) {
        Calculator calc = new Calculator();

        System.out.println("add(int, int) = " + calc.add(10, 20));
        System.out.println("add(int, int, int) = " + calc.add(10, 20, 30));
        System.out.println("add(double, double) = " + calc.add(10.5, 20.5));
    }
}