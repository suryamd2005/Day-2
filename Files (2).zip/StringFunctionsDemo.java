package day3;

public class StringFunctionsDemo {
    public static void main(String[] args) {

        String name = " arul antran vijay ";
        String email = "arul@company.com";
        String department = "Computer Science";

        // 1. Remove unwanted spaces from the name
        String trimmedName = name.trim();
        System.out.println("1. Trimmed Name: " + trimmedName);

        // 2. Convert the name into uppercase
        System.out.println("2. Uppercase: " + trimmedName.toUpperCase());

        // 3. Convert the name into lowercase
        System.out.println("3. Lowercase: " + trimmedName.toLowerCase());

        // 4. Find the number of characters in the name
        System.out.println("4. Length of Name: " + trimmedName.length());

        // 5. Check whether the email belongs to company domain
        System.out.println("5. Company Domain: "
                + email.endsWith("@company.com"));

        // 6. Check whether the name starts with the letter 'A'
        System.out.println("6. Starts with A: "
                + trimmedName.toUpperCase().startsWith("A"));

        // 7. Find the position of the first occurrence of 'a'
        System.out.println("7. First occurrence of 'a': "
                + trimmedName.indexOf('a'));

        // 8. Replace spaces in the name with underscore
        System.out.println("8. Replace Spaces: "
                + trimmedName.replace(" ", "_"));

        // 9. Extract the first four characters from the name
        System.out.println("9. First Four Characters: "
                + trimmedName.substring(0, 4));

        // 10. Compare the department with another department name
        String anotherDepartment = "Computer Science";
        System.out.println("10. Department Comparison: "
                + department.equals(anotherDepartment));
    }
}