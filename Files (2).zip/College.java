package day3;

interface College {
    String collegeName = "KCE";

    static void displayCollege() {
        System.out.println("College Name: " + collegeName);
    }
}

class Student implements College {
    void displayStudent() {
        System.out.println("Student Name: Shrutin");
        System.out.println("Student ID: 101");
    }
}

public class Main {
    public static void main(String[] args) {
        College.displayCollege();

        Student s = new Student();
        s.displayStudent();

        System.out.println("College: " + College.collegeName);
    }
}