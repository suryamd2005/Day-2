package day3;



public class MainApp {
    public static void main(String[] args) {

       Employees emp = new Employees(101, "Shrutin");

        emp.display();
    }
}