package day3;

abstract class BankAccount {

    // Abstract Method
    abstract void calculateInterest();

    // Normal Method
    void displayBankName() {
        System.out.println("Bank Name: State Bank");
    }
}

class SavingsAccount extends BankAccount {

    @Override
    void calculateInterest() {
        double balance = 50000;
        double interest = balance * 0.04; // 4% Interest

        System.out.println("Savings Account Interest: Rs." + interest);
    }
}

class CurrentAccount extends BankAccount {

    @Override
    void calculateInterest() {
        double balance = 50000;
        double interest = balance * 0.02; // 2% Interest

        System.out.println("Current Account Interest: Rs." + interest);
    }
}

public class BankDemo {
    public static void main(String[] args) {

        BankAccount sa = new SavingsAccount();
        sa.displayBankName();
        sa.calculateInterest();

        System.out.println();

        BankAccount ca = new CurrentAccount();
        ca.displayBankName();
        ca.calculateInterest();
    }
}
