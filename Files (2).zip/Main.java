package day3;
interface College {

    // Interface Variable (public static final by default)
    String collegeName = "KCE";

    // Static Method
    static void displayCollege() {
        System.out.println("College Name: " + collegeName);
    }
}

class Student implements College {
    int studentId;
    String studentName;

    Student(int studentId, String studentName) {
        this.studentId = studentId;
        this.studentName = studentName;
    }

    void displayStudent() {
        System.out.println("Student ID: " + studentId);
        System.out.println("Student Name: " + studentName);
    }
}

public class Main {
    public static void main(String[] args) {

        // Call interface static method
        College.displayCollege();

        Student s = new Student(101, "Shrutin");

        s.displayStudent();

        // Access interface variable
        System.out.println("College: " + College.collegeName);
    }
}