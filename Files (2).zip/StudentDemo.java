package day3;

class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

class Student extends Person {
    int rollNo;
    String department;

    Student(String name, int age, int rollNo, String department) {
        super(name, age); // Calls Parent Class Constructor
        this.rollNo = rollNo;
        this.department = department;
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Roll No: " + rollNo);
        System.out.println("Department: " + department);
    }
}

public class StudentDemo {
    public static void main(String[] args) {
        Student s1 = new Student("Shrutin", 20, 101, "Computer Science");

        s1.display();
    }
}