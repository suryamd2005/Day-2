package day3;

class Employee {
    void calculateSalary() {
        System.out.println("Calculating Employee Salary");
    }
}

class FullTimeEmployee extends Employee {
    @Override
    void calculateSalary() {
        int monthlySalary = 50000;
        System.out.println("Full-Time Employee Salary: Rs." + monthlySalary);
    }
}

class PartTimeEmployee extends Employee {
    @Override
    void calculateSalary() {
        int hoursWorked = 80;
        int ratePerHour = 300;
        int salary = hoursWorked * ratePerHour;

        System.out.println("Part-Time Employee Salary: Rs." + salary);
    }
}

public class EmployeeDemo {
    public static void main(String[] args) {

        Employee emp1 = new FullTimeEmployee();
        Employee emp2 = new PartTimeEmployee();

        emp1.calculateSalary();
        emp2.calculateSalary();
    }
}