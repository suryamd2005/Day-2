package day3;

interface Payment {

    // Abstract Method
    void makePayment(double amount);
}

class UPIPayment implements Payment {

    @Override
    public void makePayment(double amount) {
        System.out.println("Payment of Rs." + amount + " made using UPI.");
    }
}

class CardPayment implements Payment {

    @Override
    public void makePayment(double amount) {
        System.out.println("Payment of Rs." + amount + " made using Card.");
    }
}

public class PaymentDemo {
    public static void main(String[] args) {

        Payment p1 = new UPIPayment();
        p1.makePayment(1500.0);

        Payment p2 = new CardPayment();
        p2.makePayment(2500.0);
    }
}