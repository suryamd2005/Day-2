package Task2;

import java.util.Scanner;

public class Exersice1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input number of employees
        System.out.print("Enter number of employees: ");
        int n = sc.nextInt();

        int[] salaries = new int[n];

        // Input salaries
        System.out.println("Enter employee salaries:");
        for (int i = 0; i < n; i++) {
            salaries[i] = sc.nextInt();
        }

        int highest = salaries[0];
        int lowest = salaries[0];
        int sum = 0;

        // Find highest, lowest, and sum
        for (int i = 0; i < n; i++) {
            if (salaries[i] > highest) {
                highest = salaries[i];
            }

            if (salaries[i] < lowest) {
                lowest = salaries[i];
            }

            sum += salaries[i];
        }

        double average = (double) sum / n;

        // Count employees earning above average
        int count = 0;
        for (int i = 0; i < n; i++) {
            if (salaries[i] > average) {
                count++;
            }
        }

        // Output
        System.out.println("Highest Salary: " + highest);
        System.out.println("Lowest Salary: " + lowest);
        System.out.println("Average Salary: " + average);
        System.out.println("Employees Earning Above Average: " + count);

        sc.close();
    }
}